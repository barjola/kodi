import sys
import json
import os
import urllib.request
from urllib.parse import parse_qsl, urlencode
from datetime import datetime
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Get the plugin url
_url = sys.argv[0]
# Get the plugin handle
_handle = int(sys.argv[1])

addon = xbmcaddon.Addon()
EVENTS_URL = "https://ms.barjola.es/barjola/acestream/table"
EVICT_URL = "https://ms.barjola.es/barjola/acestream/table/evict"

def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.
    :param kwargs: "argument=value" pairs
    :return: plugin call URL
    """
    return '{}?{}'.format(_url, urlencode(kwargs))

def get_events(url_to_fetch=EVENTS_URL):
    """
    Fetch the events from the URL.
    """
    try:
        with urllib.request.urlopen(url_to_fetch) as url:
            data = json.loads(url.read().decode())
            return data
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Failed to fetch events: {e}")
        return []

def play_video(link):
    """
    Play the video.
    """
    if "acestream://" in link:
        link = link.replace("acestream://", "plugin://script.module.horus?action=play&id=")

    xbmc.Player().play(link)

def list_events(events_data=None):
    """
    Create the list of sports events in the Kodi interface.
    """
    if events_data is not None:
        events = events_data
    else:
        events = get_events()

    deportes_path = os.path.join(addon.getAddonInfo('path'), 'resources', 'deportes')

    # Logic to determine colors
    now = datetime.now()
    current_day_index = now.weekday()
    current_hour = now.hour
    current_minute = now.minute

    # Map Spanish days to 0-6
    days_map = {
        "lunes": 0, "martes": 1, "miercoles": 2, "miércoles": 2,
        "jueves": 3, "viernes": 4, "sabado": 5, "sábado": 5, "domingo": 6
    }

    current_ts = current_day_index * 24 * 60 + current_hour * 60 + current_minute

    processed_events = []
    past_indices = []

    for index, event in enumerate(events):
        fecha_str = event.get('fecha', '').lower().strip()
        hora_str = event.get('hora', '00:00').strip()

        day_idx = days_map.get(fecha_str)

        # Calculate TS
        if day_idx is not None:
            try:
                h, m = map(int, hora_str.split(':'))
                event_ts = day_idx * 24 * 60 + h * 60 + m
            except:
                event_ts = 99999999 # Treat as future if time parse fails
        else:
             event_ts = 99999999 # Treat as future if day parse fails

        is_past = False
        if day_idx is not None and event_ts <= current_ts:
             is_past = True

        processed_events.append({
            'original': event,
            'ts': event_ts,
            'is_past': is_past,
            'original_index': index
        })

        if is_past:
            past_indices.append(index)

    # Find active event (latest past)
    green_index = -1
    if past_indices:
        max_ts = -1
        for idx in past_indices:
            # idx is the index in processed_events/events
            ts = processed_events[idx]['ts']
            if ts >= max_ts:
                max_ts = ts
                green_index = idx

    for index, p_event in enumerate(processed_events):
        event = p_event['original']
        fecha = event.get('fecha', 'Unknown Date')
        hora = event.get('hora', 'Unknown Date')
        titulo = event.get('titulo', 'Unknown Title')
        deporte = event.get('tipo')

        # Color Logic
        color_tag_start = ""
        color_tag_end = ""

        diff = current_ts - p_event['ts']

        if diff > 120 and diff < 180:
            color_tag_start = "[COLOR yellow]"
            color_tag_end = "[/COLOR]"
        elif index == green_index:
            color_tag_start = "[COLOR green]"
            color_tag_end = "[/COLOR]"
        elif p_event['is_past']:
            color_tag_start = "[COLOR red]"
            color_tag_end = "[/COLOR]"

        # Day Display Logic
        display_fecha = fecha
        fecha_lower = fecha.lower().strip()
        if days_map.get(fecha_lower) == current_day_index:
            display_fecha = ""

        if display_fecha:
            label_text = f"{display_fecha} - {hora} - {titulo}"
        else:
            label_text = f"{hora} - {titulo}"

        label = f"{color_tag_start}{label_text}{color_tag_end}"

        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', {'title': label, 'plot': label})

        # Set the icon based on the sport
        if deporte:
            icon_filename = f"{deporte}.jpg"
            icon_path = os.path.join(deportes_path, icon_filename)
            if not os.path.exists(icon_path):
                icon_path = os.path.join(deportes_path, 'default.jpg')
        else:
            icon_path = os.path.join(deportes_path, 'default.jpg')

        list_item.setArt({'icon': icon_path, 'thumb': icon_path})

        # Create a URL for the plugin to call itself and list the URLs for this event
        # We pass the index of the event in the sorted list
        url = get_url(action='listing', index=p_event['original_index'])

        # isFolder=True means this item opens a subdirectory
        xbmcplugin.addDirectoryItem(_handle, url, list_item, isFolder=True)

    # Add item to reload/evict cache
    list_item = xbmcgui.ListItem(label="Actualizar eventos")
    url = get_url(action='evict')
    xbmcplugin.addDirectoryItem(_handle, url, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(_handle)

def list_urls(index):
    """
    List the URLs for a specific event.
    """
    events = get_events()
    if index < 0 or index >= len(events):
        xbmcgui.Dialog().ok("Error", "Invalid event index")
        return

    event = events[index]
    urls = event.get('urls', [])

    for item in urls:
        url_link = item.get('url', '')
        name = item.get('name', url_link)

        # Create a list item
        list_item = xbmcgui.ListItem(label=name)

        # Set info so it looks nice
        list_item.setInfo('video', {'title': name})

        # We treat these as playable items (isFolder=False)
        # Kodi will attempt to play/open the URL
        url = get_url(action='play', link=url_link)
        xbmcplugin.addDirectoryItem(_handle, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)

def router(paramstring):
    """
    Router function that calls other functions depending on the provided paramstring
    :param paramstring: URL encoded plugin paramstring
    :return:
    """
    params = dict(parse_qsl(paramstring))

    if params:
        if params.get('action') == 'listing':
            try:
                index = int(params.get('index'))
                list_urls(index)
            except (ValueError, TypeError):
                xbmcgui.Dialog().ok("Error", "Invalid index parameter")
        elif params.get('action') == 'play':
            link = params.get('link')
            play_video(link)
        elif params.get('action') == 'evict':
            events = get_events(EVICT_URL)
            list_events(events_data=events)
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception.
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the main menu
        list_events()

if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
