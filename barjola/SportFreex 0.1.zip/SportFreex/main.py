import xbmc
import xbmcgui
import requests

def extraer_enlaces(html):
    url = "https://192.168.0.200/barjola/acestream/links"  # Replace with the actual API URL

    response = requests.get(url)  # Sending GET request to the API
    data = response.json()  # Parsing the JSON response

    enlaces = []
    titulos = []

    for item in data:

        nuevo_enlace = item['acestream'].replace("acestream://", "plugin://script.module.horus?action=play&id=")
        enlaces.append(nuevo_enlace)

        titulos.append(f"{item['texto'].strip()} {item['acestream'][-4:]}")
    
    return enlaces, titulos

def reproducir_enlace(enlace):
    xbmc.Player().play(enlace)

def main():    
    enlaces, titulos = extraer_enlaces()

    print(enlaces)
    
    if not enlaces:
        xbmcgui.Dialog().notification("Error", "No se encontraron enlaces.")
        return
    
    seleccion = xbmcgui.Dialog().select("Selecciona un enlace", titulos)
    
    if seleccion != -1:
        reproducir_enlace(enlaces[seleccion])

if __name__ == '__main__':
    main()
