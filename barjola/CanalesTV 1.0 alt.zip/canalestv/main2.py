import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib2
import re
import urlparse
import sys

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])

def obtener_contenido_web(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        req = urllib2.Request(url, headers=headers)
        response = urllib2.urlopen(req)
        return response.read().decode('utf-8')
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e))
        return ""

def extraer_enlaces(html):
    enlaces = []
    titulos = []
    patrones = re.findall(r'<a href="(acestream://[^"]+)"[^>]*>(.*?)</a>', html)
    for enlace, titulo in patrones:
        nuevo_enlace = enlace.replace("acestream://", "plugin://script.module.horus?action=play&id=")
        enlaces.append(nuevo_enlace)
        id_acestream = enlace.split("://")[1] 
        ultimos_digitos = id_acestream[-4:]
        titulos.append(titulo.strip())
    return enlaces, titulos

def listar_enlaces():
    url_web = "https://barjola.es/acestream/links" 
    contenido_html = obtener_contenido_web(url_web)
    
    if not contenido_html:
        return
    
    enlaces, titulos = extraer_enlaces(contenido_html)
    
    if not enlaces:
        xbmcgui.Dialog().notification("Error", "No se encontraron enlaces.")
        return
    
    for titulo, enlace in zip(titulos, enlaces):
        list_item = xbmcgui.ListItem(label=titulo)
        list_item.setProperty('IsPlayable', 'true')
        url = "{0}?action=play&url={1}".format(sys.argv[0], urllib2.quote(enlace))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(addon_handle)

def reproducir_enlace(url):
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def router(paramstring):
    params = dict(urlparse.parse_qsl(paramstring))
    if params:
        if params['action'] == 'play':
            reproducir_enlace(params['url'])
    else:
        listar_enlaces()

if __name__ == '__main__':
    router(sys.argv[2][1:])