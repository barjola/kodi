import xbmc
import xbmcgui
import urllib.request
import re


def obtener_contenido_web(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e))
        return ""

def extraer_enlaces(html):
    enlaces = []
    titulos = []
    
    patrones = re.findall(r'<a href="(acestream://[^"]+)"[^>]*>(.*?)</a>', html)

    for enlace, titulo in patrones:
        nuevo_enlace = enlace.replace("acestream://", "plugin://script.module.horus?action=play&id=")
        enlaces.append(nuevo_enlace)

        id_acestream = enlace.split("://")[1] 
        ultimos_digitos = id_acestream[-4:]

        titulos.append(titulo.strip())
    
    return enlaces, titulos

def reproducir_enlace(enlace):
    xbmc.Player().play(enlace)

def main():
    url_web = "https://barjola.github.io/kodi/enlaces/links.html" 
    contenido_html = obtener_contenido_web(url_web)
    
    if not contenido_html:
        return
    
    enlaces, titulos = extraer_enlaces(contenido_html)

    print(enlaces)
    
    if not enlaces:
        xbmcgui.Dialog().notification("Error", "No se encontraron enlaces.")
        return
    
    seleccion = xbmcgui.Dialog().select("Selecciona un enlace", titulos)
    
    if seleccion != -1:
        reproducir_enlace(enlaces[seleccion])

if __name__ == '__main__':
    main()
