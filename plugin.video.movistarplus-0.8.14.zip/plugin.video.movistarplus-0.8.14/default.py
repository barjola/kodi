# encoding: utf-8
#
# SPDX-License-Identifier: LGPL-2.1-or-later

from resources.lib.plugin import run

run()


